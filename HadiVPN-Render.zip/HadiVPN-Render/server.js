'use strict';

const http = require('node:http');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 10000);
const XRAY_PORT = 10001;
const WS_PATH = process.env.WS_PATH || '/hadi-ws';
const UUID = process.env.UUID || '';
const CONFIG_PATH = '/tmp/hadivpn-xray.json';

// The VLESS client identifier must be a standard UUID. Do not place it in source control.
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
if (!UUID_RE.test(UUID)) {
  console.error('Configuration error: set UUID to a valid UUID v4 in the hosting environment.');
  process.exit(1);
}
if (!WS_PATH.startsWith('/') || WS_PATH.includes(' ') || WS_PATH.includes('?') || WS_PATH.includes('#')) {
  console.error('Configuration error: WS_PATH must be a URL path such as /hadi-ws.');
  process.exit(1);
}

const xrayConfig = {
  log: { loglevel: 'warning' },
  inbounds: [{
    listen: '127.0.0.1',
    port: XRAY_PORT,
    protocol: 'vless',
    settings: {
      clients: [{ id: UUID }],
      decryption: 'none'
    },
    streamSettings: {
      network: 'ws',
      security: 'none',
      wsSettings: { path: WS_PATH }
    },
    sniffing: { enabled: true, destOverride: ['http', 'tls'] }
  }],
  outbounds: [{ protocol: 'freedom', tag: 'direct' }]
};
fs.writeFileSync(CONFIG_PATH, JSON.stringify(xrayConfig));

const xray = spawn('/usr/local/bin/xray', ['run', '-c', CONFIG_PATH], {
  stdio: ['ignore', 'ignore', 'inherit']
});
xray.on('error', (err) => {
  console.error('Could not start Xray:', err.message);
  process.exit(1);
});
xray.on('exit', (code, signal) => {
  console.error(`Xray exited (code=${code}, signal=${signal || 'none'}). Shutting down.`);
  process.exit(code || 1);
});

const server = http.createServer((req, res) => {
  const path = new URL(req.url || '/', 'http://localhost').pathname;
  if (req.method === 'GET' && (path === '/health' || path === '/')) {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ name: 'HadiVPN', status: 'gateway-running', websocketPath: WS_PATH }));
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
  res.end('Not found');
});

server.on('upgrade', (req, clientSocket, head) => {
  let pathname;
  try {
    pathname = new URL(req.url || '/', 'http://localhost').pathname;
  } catch {
    clientSocket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
    return;
  }
  if (pathname !== WS_PATH) {
    clientSocket.end('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    return;
  }

  const upstream = http.request({
    host: '127.0.0.1',
    port: XRAY_PORT,
    method: 'GET',
    path: req.url,
    headers: req.headers
  });
  let upgraded = false;

  upstream.on('upgrade', (upstreamRes, upstreamSocket, upstreamHead) => {
    upgraded = true;
    const statusLine = `HTTP/1.1 ${upstreamRes.statusCode || 101} ${upstreamRes.statusMessage || 'Switching Protocols'}`;
    const responseHeaders = [statusLine];
    for (const [key, value] of Object.entries(upstreamRes.headers)) {
      if (value === undefined) continue;
      const values = Array.isArray(value) ? value : [value];
      for (const item of values) responseHeaders.push(`${key}: ${item}`);
    }
    clientSocket.write(responseHeaders.join('\r\n') + '\r\n\r\n');
    if (upstreamHead.length) clientSocket.write(upstreamHead);
    if (head.length) upstreamSocket.write(head);
    upstreamSocket.pipe(clientSocket);
    clientSocket.pipe(upstreamSocket);
    upstreamSocket.on('error', () => clientSocket.destroy());
    clientSocket.on('error', () => upstreamSocket.destroy());
    clientSocket.on('close', () => upstreamSocket.destroy());
    upstreamSocket.on('close', () => clientSocket.destroy());
  });

  upstream.on('response', (response) => {
    if (upgraded) return;
    clientSocket.write(`HTTP/1.1 ${response.statusCode || 502} ${response.statusMessage || 'Bad Gateway'}\r\nConnection: close\r\n\r\n`);
    response.pipe(clientSocket);
  });
  upstream.on('error', () => {
    if (!clientSocket.destroyed) {
      clientSocket.end('HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n');
    }
  });
  upstream.end();
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`HadiVPN gateway listening on port ${PORT}; WebSocket path ${WS_PATH}`);
});

function shutdown() {
  server.close(() => {});
  xray.kill('SIGTERM');
  setTimeout(() => process.exit(0), 1500).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
