# HadiVPN — Render WebSocket gateway

A minimal VLESS-over-WebSocket gateway using Xray-core, packaged for a Render **free** web service. Render terminates HTTPS and the app forwards WebSocket upgrades to a private local Xray listener. Cloudflare is not required for the first test; use the Render `onrender.com` hostname directly first.

> **Important:** this is an initial deployment scaffold, not a claim that the service has already been deployed or tested on an Iranian ISP. Render free resources can be interrupted or spin down, and the service may be blocked by a network. Never treat a successful `/health` response as proof that VPN traffic works; test a real client connection.

## Files

- `Dockerfile` — pinned Xray image plus Node WebSocket gateway.
- `server.js` — health endpoint and WebSocket upgrade proxy.
- `render.yaml` — Render Blueprint, set to the free Frankfurt region.

## Deploy from GitHub without a terminal

1. Create a **new repository** on GitHub. A private repository is preferable because this project is for your own VPN.
2. Upload all files from this folder to the repository root (extract the ZIP first; do not upload the ZIP itself as the only file).
3. Open `https://dashboard.render.com/blueprint/new?repo=https://github.com/OWNER/REPOSITORY` after replacing `OWNER/REPOSITORY` with the new repository path.
4. Review the Blueprint and select **free** only. During the initial setup, Render will prompt for `UUID`.
5. Generate a standards-compliant UUID v4 using a trusted offline UUID generator, and enter it in the Render prompt. Keep the same value private. Do not add it to GitHub or share it publicly.
6. Let the first deploy finish, then open `https://YOUR-SERVICE.onrender.com/health`. A JSON response with `"status":"gateway-running"` confirms only that the web gateway is up.
7. In a VLESS client, use these settings:
   - Protocol: `VLESS`
   - Address: your Render service hostname, without `https://`
   - Port: `443`
   - UUID: the secret value you set in Render
   - Transport: `WebSocket (ws)`
   - WebSocket path: `/hadi-ws`
   - TLS: enabled
   - SNI / server name: your Render hostname

## Notes and limitations

- The Render Blueprint creates no databases, paid instances, or additional services; `plan: free` is specified explicitly.
- Do not enable Cloudflare proxying until direct Render connectivity has been tested. A Cloudflare proxy puts Cloudflare back in the network path and is not automatically more resistant to filtering.
- This is a basic VLESS/WS transport, not a magic way to disguise all VPN traffic as Google or ChatGPT.
- Check current Xray / Render documentation before production use. Keep dependencies and the pinned Xray version updated deliberately.
